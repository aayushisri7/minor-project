<html>
<head>
  <style>
  #footer {

  position:absolute;
  left: 0;
  bottom: 0;
  width: 100%;
  height: 75px;
  background-color:#000000;
  color:white;
  text-align: center;
}
  </style>
</head>
<body>
  <div id="footer" >
  <b><center>COPYRIGHT © 2023<br>
  Drop Red
  <br>
  ALL RIGHTS RESERVED.
  </center>
  </div>


</body>

</html>
