<?php
$conn=mysqli_connect("localhost","root","","blood_donation") or die("Connection error");
?>
